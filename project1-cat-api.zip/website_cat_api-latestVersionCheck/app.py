from server import app
##takes the app from server and runs it
if __name__ == '__main__':
    app.run(use_reloader=True)
