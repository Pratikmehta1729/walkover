import sqlite3
from datetime import date
from datetime import timedelta 
conn = sqlite3.connect('database/trends.db')
# cursor = conn.execute("SELECT * FROM data ")
clusterNo=1
url=str("https://google.com")
cursor = conn.execute("SELECT c"+str(clusterNo)+" from KEYWORDS where Day='"+str(date.today() - timedelta(days = 1))+"'")
# cursor = conn.execute("SELECT cluster_no,embedding from data where url='"+str(url)+"'")
# cursor = conn.execute("SELECT c"+str(clusterNo)+" from KEYWORDS where Day='"+str(date.today())+"'")
# cursor = conn.execute("SELECT day from keywords ")
for row in cursor:
  print(row)
  
