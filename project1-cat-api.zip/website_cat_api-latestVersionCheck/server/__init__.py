import pandas as pd
import numpy as np
import json
import urllib.parse
from flask import Flask
from flask_cors import CORS, cross_origin
import server.initialize
from server.get_result import finalFunction


print("in app")



app = Flask(__name__)


cors = CORS(app)
app.config['CORS_HEADERS'] = '*'

@app.route('/<path:url>')
@app.route('/')
@cross_origin()
def result_url(url=''):
    print(url)
    return finalFunction(url)

